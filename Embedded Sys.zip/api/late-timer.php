<?php

date_default_timezone_set("Africa/Nairobi");

function late_time_processor($param){
    $con_obj = new AmadiDBConnection("biometric_system");
    $con_init = $con_obj->connect();
    $con = $con_init["connection"];

    $sql = "SELECT * FROM `configurations`";
    $result = $con->query($sql);

    if (!$result) {
        echo json_encode([
            "status" => "fail",
            "msg" => "SERVER_CONN_ERR"
        ]);
        exit();
    }

    if ($result->num_rows < 1) {
        return;
    }

    $clocked_in_time = date("H:i");
    $time_allowance = 10 * 60;
    
    $default_late_time = $result->fetch_assoc()["time_in"]; 

    $time_difference = strtotime($clocked_in_time) - strtotime($default_late_time) + $time_allowance;

    if ($time_difference > 1) {
      
        $args = [
            "user_id" => $param,
            "date" => date("Y-m-d"),
            "minutes_late" => $time_difference / 60,
            "clock_in_time" => date("H:i"),
            "time_allowance" => $time_allowance,
            "timestamp" => date("Y-m-d H:i:s"),
        ];

        record_to_late($con, $args);
    }
    return;
}

function record_to_late($con, $params) {
    $sql = "INSERT INTO `late_comers` (user_id, date, minutes_late, clock_in_time, time_allowance, timestamp) 
            VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $con->stmt_init();

    if (!$stmt || !$stmt->prepare($sql)) {
        echo json_encode([
            "status" => "fail",
            "msg" => "INTERNAL_SERVER_ERR"
        ]);
        exit();
    }

    $stmt->bind_param(
        "ssssss",
        $params["user_id"],
        $params["date"],
        $params["minutes_late"],
        $params["clock_in_time"],
        $params["time_allowance"],
        $params["timestamp"]
    );

    if (!$stmt->execute()) {
        report_error();
    }

    email_alert($con, $params["user_id"], $params["minutes_late"], $params["clock_in_time"]);
}

function email_alert($con, $user_id, $minutes_late, $clock_in_time) {
    $sql = "SELECT * FROM `members` WHERE user_id = ?";
    $stmt = $con->prepare($sql);

    if (!$stmt || !$stmt->bind_param("i", $user_id)) {
        report_error();
    }

    $stmt->execute();
    $result = $stmt->get_result();

    if (!$result || $result->num_rows < 1) {
        return; 
    }

    $user = $result->fetch_assoc();
    $username = $user["name"];
    $email = "amadicollims5872@gmail.com";

    
    $subject = "Late Comer Alert | " . $username;
    $from = "admin@amadi.tech";
    $to = $email;  
    
    
    $headers = "MIME-Version: 1.0" . "\r\n";
    $headers .= "Content-type: text/html; charset=UTF-8" . "\r\n";
    $headers .= "From: admin@amadi.tech" . "\r\n";

    $message = "<!DOCTYPE html><html lang=\"en\">";
    $message .= "<head><meta charset=\"UTF-8\"><link href=\"https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap\" rel=\"stylesheet\">";
    $message .= "<link href=\"https://fonts.googleapis.com/css2?family=Montserrat:wght@400;700&display=swap\" rel=\"stylesheet\">";
    $message .= "<style>*{margin: 0 ;padding: 0;}div{width : 100vw;height: 100%;font-family : sans-serif; background: white}</style></head>";
    $message .= "<body><div style=\"text-align: center;color: maroon;font-family: serif;\">LATE COMER REPORT</div>";
    $message .= "<p><strong>User:</strong> " . $username . "</p>";
    $message .= "<p><strong>Clock-in Time:</strong> " . $clock_in_time . "</p>";
    $message .= "<p><strong>Minutes Late:</strong> " . round($minutes_late) . " minutes</p>";
    $message .= "<p><strong>Date:</strong> " . date("Y-m-d") . "</p>";
    $message .= "<p><strong>Time Allowance:</strong> 10 minutes</p>";
    $message .= "</body></html>";

    if (!mail($to, $subject, $message, $headers)) {
    
    }
}

function report_error() {
    echo json_encode([
        "status" => "fail",
        "msg" => "INTERNAL_SERVER_ERR",
        "error_log" => "An error occurred. Please check the server logs."
    ]);
    exit();
}
