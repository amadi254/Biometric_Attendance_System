<?php 

include "server--config/connection.php";

date_default_timezone_set("Africa/Nairobi");

if ($_SERVER["REQUEST_METHOD"] != "POST") {
    echo json_encode([
        "status" => "fail",
        "msg" => "ERR_REQ_METHOD",
        "error_log" => "API request failed! Unsupported Request Method",
    ]);
    exit();
}

if (empty($_POST["id"]) || !isset($_POST["id"])) {
    echo json_encode([
        "status" => "fail",
        "msg" => "NULL_ID_PARAM",
        "error_log" => "Null ID was parsed to the endpoint | API request failed",
    ]);
    exit();
}

$con_init = new AmadiDBConnection("biometric_system");
$con = $con_init->connect();

if ($con["status"] != "success") {
    echo json_encode([
        "status" => "fail",
        "msg" => "INTERNAL_SERVER_ERR",
        "error_log" => "Database connection failed. Connection ERR.",
    ]);
    exit();
}

$member_id = $con["connection"]->real_escape_string($_POST["id"]);

$sql = "SELECT * FROM `members` WHERE user_id = ?";
$stmt = $con["connection"]->prepare($sql);

if (!$stmt || !$stmt->bind_param("i", $member_id)) {
    echo json_encode([
        "status" => "fail",
        "msg" => "INTERNAL_SERVER_ERR",
        "error_log" => "Database Connection Error",
    ]);
    exit();
}

$stmt->execute();
$res = $stmt->get_result();

if (!$res) {
    echo json_encode([
        "status" => "fail",
        "msg" => "INTERNAL_SERVER_ERR",
        "error_log" => "GETTING RESULT ERROR",
    ]);
    exit();
}

if ($res->num_rows <= 0) {
    echo json_encode([
        "status" => "fail",
        "msg" => "NO_ACCOUNT_REC",
        "error_log" => "This ID " . $member_id . " has NO account linked to it",
    ]);
    exit();
}

$id_name = $res->fetch_assoc()["name"];
check_if_clocked_in_and_clock_out($con["connection"], $member_id, $id_name);

function check_if_clocked_in_and_clock_out($con, $uid, $name) {
    $todays_date = date("Y-m-d");
    $sql = "SELECT * FROM `attendance` WHERE date_in = ? AND user_id = ?";
    $stmt = $con->prepare($sql);

    if (!$stmt || !$stmt->bind_param("si", $todays_date, $uid)) {
        echo json_encode([
            "status" => "fail",
            "msg" => "INTERNAL_SERVER_ERR",
            "error_log" => "Database Query Preparation Failed",
        ]);
        return;
    }

    $stmt->execute();
    $result = $stmt->get_result();

    if (!$result) {
        echo json_encode([
            "status" => "fail",
            "msg" => "INTERNAL_SERVER_ERR",
            "error_log" => "Database Query Failed",
        ]);
        return;
    }

    if ($result->num_rows <= 0) {
        echo json_encode([
            "status" => "fail",
            "msg" => "NO_CLK_IN",
            "error_log" => "User has not clocked in today.",
        ]);
        return;
    }

    // Clock Out Logic
    clock_out_member($con, $uid, $result);
}

function clock_out_member($con, $uid, $result) {
    $time_out = date("H:i:s");
    $date = date("Y-m-d");
    $timestamp = date("Y-m-d H:i:s");

    // Fetch the record and prepare for update
    $attendance_id = $result->fetch_assoc()['attendance_id'];

    $sql = "UPDATE `attendance` SET time_out = ?, timestamp = ? WHERE attendance_id = ? AND user_id = ?";
    $stmt = $con->prepare($sql);

    if (!$stmt || !$stmt->bind_param("ssii", $time_out, $timestamp, $attendance_id, $uid)) {
        echo json_encode([
            "status" => "fail",
            "msg" => "INTERNAL_SERVER_ERR",
            "error_log" => "Failed to bind parameters for clock out",
        ]);
        return;
    }

    if (!$stmt->execute()) {
        echo json_encode([
            "status" => "fail",
            "msg" => "INTERNAL_SERVER_ERR",
            "error_log" => "Error executing clock-out query",
        ]);
        return;
    }

    echo json_encode([
        "status" => "success",
        "msg" => "Goodbye " . substr($result->fetch_assoc()['name'], 0, 9),
    ]);
    exit();
}