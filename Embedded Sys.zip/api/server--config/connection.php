<?php

// DATABASE CONNECTION 

class AmadiDBConnection {
    private $connection;
    private $hostname = "localhost";
    private $username = "root";
    private $password = "";
    private $database_name;

    public function __construct($param) {
        $this->database_name = $param;
    }

    public function connect() {
        $this->connection = mysqli_connect($this->hostname, $this->username, $this->password, $this->database_name);

        if (!$this->connection) {
            $error = [
                "type" => "DATABASE_CONNECTION_ERROR!",
                "database_name" => $this->database_name,
                "connection_error" => mysqli_connect_error(), 
                "timestamp" => date("Y-m-d H:i:s"),
                "contact" => "admin@amadi.tech"
            ];

            error_log(json_encode($error), 3, "database_connection_err-log.txt");

            return [
                "status" => "fail",
                "msg" => mysqli_connect_error(),
                "connection" => false 
            ];
        }

        return [
            "status" => "success",
            "connection" => $this->connection
        ];
    }
}
