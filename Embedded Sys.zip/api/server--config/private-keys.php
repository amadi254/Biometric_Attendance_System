<?php
    
$database_pwd = " ";